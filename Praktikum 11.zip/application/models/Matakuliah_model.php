<?php
    class Matakuliah_model extends CI_Model{
        
        public $kode;
        public $nama;
        public $sks;

    }
?>