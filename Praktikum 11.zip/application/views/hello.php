<h2><?php echo $title?></h2>
<h1>Welcome! <?=$nama?></h1>